from .krita_renpy_scripter import registerDocker

registerDocker()