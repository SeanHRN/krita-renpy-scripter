from .kritaRenpyScripter import registerDocker

registerDocker()