from .generateRenpyScripting import registerDocker

registerDocker()